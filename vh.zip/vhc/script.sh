#!/bin/bash
sudo mkdir -p /var/www/gitlab.workbyte.in/public_html
sudo cp index.html /var/www/gitlab.workbyte.in/public_html/index.html
sudo chown -R $USER:$USER /var/www/gitlab.workbyte.in/public_html
sudo chmod -R 755 /var/www
sudo cp gitlab.workbyte.in.conf /etc/apache2/sites-available/gitlab.workbyte.in.conf
sudo a2ensite gitlab.workbyte.in.conf
sudo /etc/init.d/apache2 restart